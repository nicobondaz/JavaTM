package ar.org.trabajo.centro8.java;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrimerTrabajoC8Application {

	public static void main(String[] args) {
		SpringApplication.run(PrimerTrabajoC8Application.class, args);
	}

}
