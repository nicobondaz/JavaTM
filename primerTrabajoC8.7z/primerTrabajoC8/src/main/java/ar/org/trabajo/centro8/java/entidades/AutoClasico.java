package ar.org.trabajo.centro8.java.entidades;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class AutoClasico extends Vehiculo {
    
    
    private Double precio;
    private Radio radio;

    public AutoClasico(String marca, String modelo, String color) {
        super(marca, modelo, color);
        
    }

    @Override
    public void tipoVehiculo() {
        System.out.println("Es un auto clasico");
        throw new UnsupportedOperationException("Unimplemented method 'tipoVehiculo'");
    }

    }

    


