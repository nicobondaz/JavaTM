package ar.org.trabajo.centro8.java.entidades;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class AutoNuevo extends Vehiculo {

    private Radio Radio;
    private Double Double;

    public AutoNuevo(String marca, String modelo, String color, Radio radio) {
        super(marca, modelo, color);
        if (radio == null) {
            System.out.println("No se puedde crear un auto sin radio");
        }
         this.Radio = radio;
    }

    @Override
    public void tipoVehiculo() {
        System.out.println("Es un auto nuevo");
        throw new UnsupportedOperationException("Unimplemented method 'tipoVehiculo'");
    }

    


    
}
