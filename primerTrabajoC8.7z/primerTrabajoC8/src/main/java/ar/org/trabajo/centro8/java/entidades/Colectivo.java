package ar.org.trabajo.centro8.java.entidades;

public class Colectivo {

}
