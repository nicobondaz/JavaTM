package ar.org.trabajo.centro8.java.entidades;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@ToString
public class Radio {
    private String marca;
    private String potencia;
    

    
}
