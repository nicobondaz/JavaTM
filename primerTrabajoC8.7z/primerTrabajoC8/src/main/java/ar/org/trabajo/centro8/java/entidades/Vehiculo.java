package ar.org.trabajo.centro8.java.entidades;

import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public abstract class Vehiculo {

    private String marca;
    private String modelo;
    private String color;
    private Double precio;
    private Radio radio;


    public Vehiculo(String marca, String modelo, String color) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
    }
    public void agregarRadio(Radio radio){
        if (this.radio == null) {
            this.radio = radio;
        }
    }
    public void quitarRadio(Radio radio){
        if (this.radio != null) {
            this.radio = null;
        }
    }

    public abstract void tipoVehiculo();
    

}
