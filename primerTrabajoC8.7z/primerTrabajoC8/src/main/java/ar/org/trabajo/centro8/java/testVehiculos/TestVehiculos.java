package ar.org.trabajo.centro8.java.testVehiculos;

public class TestVehiculos {
    public static void main(String[] args) {
        
    }
}
