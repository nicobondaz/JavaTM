package ar.org.trabajo.centro8.java;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrimerTrabajoC8ApplicationTests {

	@Test
	void contextLoads() {
	}

}
